#!/usr/bin/env python3
# Copyright (c) 2023 The Sapeon Authors. All rights reserved.

import argparse
import glob
from ntpath import join
import subprocess
import sys
import os

from pip import __main__
VERSION = '1.2.1'
X220_CORE_PWR = 65

IS_TEST = False

class DeviceManager:
    def __init__(self, is_test, sort, i):
        self.is_test = is_test
        self.sort = sort
        self.i = i

    def __get_bdf(self, device_type):
        if self.is_test == 0:
            command = 'lspci -n | grep 1f56:' if device_type == 'sapeon' else 'lspci -n | grep 1556:'
            stream = os.popen(command)
        else:
            file_path = f"./test/lspci_grep_1f56.txt" if device_type == 'sapeon' else f"./test/lspci_grep_1556.txt"
            stream = open(file_path)

        outputs = stream.read().splitlines()
        stream.close()
        bdfs = [out.split()[0] for out in outputs]
        return bdfs

    def __get_devices(self, device_type):
        path = f'./test/sys/class/{device_type}/' if self.is_test else f'/sys/class/{device_type}/'

        if self.i != -1:
            devices = glob.glob(path + f'snx3-{self.i}') if device_type == 'sapeon' else glob.glob(path + f'{device_type}{self.i}')
        else:
            devices = sorted(glob.glob(path + f'snx3-*')) if device_type == 'sapeon' else sorted(glob.glob(path + f'{device_type}*'))

        return devices

    def get_all_devices_and_bdfs(self):
        x330_devices = self.__get_devices('sapeon')
        x330_bdfs = self.__get_bdf('sapeon')
        x220_devices = self.__get_devices('aix')
        x220_bdfs = self.__get_bdf('aix')
        all_devices = x330_devices + x220_devices
        all_bdfs = x330_bdfs + x220_bdfs

        if self.sort == True:
            sorted_data = sorted(zip(all_bdfs, all_devices), key=lambda x: int(x[0].split(':')[0], 16))
            all_bdfs = [item[0] for item in sorted_data]
            all_devices = [item[1] for item in sorted_data]

        return x330_devices, x330_bdfs, x220_devices, x220_bdfs, all_devices, all_bdfs

def get_device_status(device):
    monitor = device + '/aix_status_monitor'
    f = open(monitor)
    data = f.readline().rstrip('\n')
    if (len(data) == 0):
        sys.exit("error: cannot read a device status")
    status = (' '.join(data.split())).split(' ')
    #print(status)
    return status

def get_hw_version(device, i):
    if device == 'x330':
        return {
            0x00 : ('X330 EVB', 'REV0'),
            0x01 : ('X330 Compact', 'I.0/1'),
            0x02 : ('X330 Compact', 'I.2'),
            0x03 : ('X330 Compact', 'I.3'),
            0x04 : ('X330 Prime', 'I.0')
            }.get(i, ('Unknown', 'N/A'))
    elif device == 'x220':
        return {
            0x00 : ('X220 Compact', 'K0'),
            0x01 : ('X220 Compact', 'K1'),
            0x02 : ('X220 Compact', 'K2'),
            0x03 : ('X220 Compact', 'K3'),
            0x04 : ('X220 Enterprise', 'E0'),
            0xA1 : ('X220 Enterprise', 'E1'),
            0xA2 : ('X220 Enterprise', 'E2')
            }.get(i, ('Unknown', 'N/A'))

def print_header():
    if (IS_TEST):
        X330_FE_DRV_VER = X330_BE_DRV_VER = X220_FE_DRV_VER = X220_BE_DRV_VER = f"vTest"
    else :
        if os.path.exists("/sys/module/sapeon/version"):
            with open("/sys/module/sapeon/version", "r") as f :
                X330_FE_DRV_VER = f"v{f.readline().strip()}"
            with open("/sys/module/snx3/version", "r") as f :
                X330_BE_DRV_VER = f"v{f.readline().strip()}"
        else:
            X330_FE_DRV_VER = X330_BE_DRV_VER = f"-"
        if os.path.exists("/sys/module/frontend/version"):
            with open("/sys/module/frontend/version", "r") as f :
                X220_FE_DRV_VER = f"v{f.readline().strip()}"
            with open("/sys/module/backend/version", "r") as f :
                X220_BE_DRV_VER = f"v{f.readline().strip()}"
        else:
            X220_FE_DRV_VER = X220_BE_DRV_VER = f"-"

    print('+------------------------------------------------------------------------------------------------+')
    print('| SAPEON-SMI {:54} SMI-version: v{:<14} |'.format('', VERSION, ''))
    print("| {:57} x330 Driver (FE/BE): {:^6} / {:^6} |".format('', X330_FE_DRV_VER, X330_BE_DRV_VER))
    print("| {:57} x220 Driver (FE/BE): {:^6} / {:^6} |".format('', X220_FE_DRV_VER, X220_BE_DRV_VER))
    print('+------------------------------------------------------------------------------------------------+')
    print(f"|{'Product':^18}|{'Rev':^7}|{'SN':^10}|{'Bus':^10}|{'FW Ver':^11}|{'Temp1':^9}|{'Temp2':^9}|{'Power':^8}|{'Util':^6}|")
    print('+------------------------------------------------------------------------------------------------+')

def print_devices_status(devices, bdfs):

    for i, device in enumerate(devices):

        status = get_device_status(device)
        sid = device.split('/')[-1]
        sid = sid.split('-')[-1]

        if f'sapeon' in device:
            device_name, hw_rev = get_hw_version('x330', int(status[0], 16))
            chip_id     = int(status[1])
            if (status[4] == '00000000'):
                serial = 'N/A'
            else :
                feature = status[4]
                year = int(feature[0:2], 16)
                month = int(feature[2:3], 16) + ord("A") - 1
                model = int(feature[-5:], 16)
                model_str = '{:05d}'.format(model)
                serial = str(year) + chr(month) + model_str
            project_id  = int(status[3])
            sw_ver      = status[5]
            mcu_ver     = status[6]
            temp1        = (float(status[7]) + float(status[8]) + float(status[9]) + float(status[10]))/4/2
            power1      = int(status[11])/1000 if int(status[11]) < 0xFFFE else -1 # Sensor error will be reported as 0xFFFF or 0xFFFE
            power2      = int(status[12])/1000 if int(status[12]) < 0xFFFE else -1
            power3      = int(status[13])/1000 if int(status[13]) < 0xFFFE else -1
            power4      = int(status[14])/1000 if int(status[14]) < 0xFFFE else -1
            power5      = int(status[15])/100 if int(status[15]) < 0xFFFE else -1
            load        = int((int(status[16]) + int(status[17]) + int(status[18]) + int(status[19]) ) / 4)
            power_total = power1 + power2 + power3 + power4

            print(f'|{device_name:^18}|{hw_rev:^7}|{serial:^10}|{bdfs[i]:^10}| {sw_ver}.{mcu_ver} |{temp1:>6.1f}\xb0C |   N/A   |{power5:>6.1f}W |{load:>4}% |')
        else :
            device_name, hw_rev = get_hw_version('x220', int(status[0], 16))
            if (status[2] == '0000'):
                serial = 'N/A'
            else :
                serial = status[2]
            sw_ver  = status[5]
            mcu_ver = status[6]
            temp1    = float(status[8])/2
            temp2    = float(status[9])/2
            power   = round((int(status[12]) * 0.025), 2) if int(status[12]) < 0xFFFE else -1
            print(f'|{device_name:^18}|{hw_rev:^7}|{serial:^10}|{bdfs[i]:^10}| {sw_ver}.{mcu_ver} |{temp1:>6.1f}\xb0C |{temp2:>6.1f}\xb0C |{power:>6.1f}W |  N/A |')

        print('+------------------------------------------------------------------------------------------------+')


def get_process_name(id):
    p = subprocess.Popen(["ps -p {} -o comm".format(id)], stdout=subprocess.PIPE, shell=True)
    return p.communicate()[0].decode("utf-8")

def print_processes(devices):
    print('+------------------------------------------------------------------------------------------------+')
    print('| Processes: {:83} |'.format(''))
    print('| Sapeon ID {:12} PID {:12} Process Name {:41} |'.format('', '', ''))
    print('+------------------------------------------------------------------------------------------------+')

    for device in devices:
        status = get_device_status(device)
        sid = device.split('/')[-1]
        if f'sapeon' in device:
            if IS_DOCKER:
                pid = int(status[21])
            else:
                pid = int(status[20])
        else :
            if IS_DOCKER:
                pid = int(status[17])
            else:
                pid = int(status[16])

        if (pid == 0): continue

        process_name = get_process_name(pid).split('\n')[1]
        print(f'| {sid:22} {pid:<16} {process_name:<54} |')

    print('+------------------------------------------------------------------------------------------------+')

def print_query_result(devices, query, model):
    if (query == 'temp'):
        print_temperature(devices, model)
    elif (query == 'power'):
        print_power(devices)
    elif (query == 'usage'):
        print_usage(devices)

def print_temperature(devices, model):
    for device in devices:
        status = get_device_status(device)

        if f'sapeon' in device:
            temp = (float(status[7]) + float(status[8]) + float(status[9]) + float(status[10]))/4/2
            if (model == 'x330'):
                print('{:.2f}C'.format(temp))
            else:
                print('{:.2f}C\nN/A'.format(temp))
        else :
            temp1 = float(status[8])/2
            temp2 = float(status[9])/2
            print('{}C\n{}C'.format(temp1, temp2))

def print_power(devices):
    for device in devices:
        status = get_device_status(device)

        if f'sapeon' in device:
            power = int(status[15])/100 if int(status[15]) < 0xFFFE else -1
        else:
            power = round(float(int(status[12])*0.025), 2) if int(status[12]) < 0xFFFE else -1

        print('{:.2f}W'.format(power) if power != -1 else "Error")

def print_usage(devices):
    for device in devices:
        status = get_device_status(device)

        if f'sapeon' in device:
            usage = int((int(status[16]) + int(status[17]) + int(status[18]) + int(status[19]) ) / 4)
        else:
            power = round(float(int(status[12])*0.025), 2) if int(status[12]) < 0xFFFE else -1
            usage = round(float(power / X220_CORE_PWR * 100))

        print('{}%'.format(usage))

def main() :
    global IS_DOCKER
    parser = argparse.ArgumentParser(description='SAPEON System Management Interface -- v' + VERSION)
    parser.add_argument('-i', type=int, default=-1, help='Target a specific SAPEON.')
    parser.add_argument('--query', type=str, default='', choices=['temp', 'power', 'usage'], help='Information about Sapeon.')
    parser.add_argument('--model', type=str, default='all', choices=['all', 'x330', 'x220'], help='Choosse the model to output the information.')
    parser.add_argument('--docker', action='store_true', help='Enable docker container mode.')
    args = parser.parse_args()

    if (args.i != -1) and (args.model == 'all'):
        sys.exit(f"error: select a model(x330 or x220) to output information for a device number")

    device_manager = DeviceManager(is_test=IS_TEST, sort=False, i=args.i)
    if (args.model == 'all'):
        _, _, _, _, all_devices, all_bdfs = device_manager.get_all_devices_and_bdfs()
    elif (args.model == 'x330'):
        all_devices, all_bdfs, _, _, _, _  = device_manager.get_all_devices_and_bdfs()
    elif (args.model == 'x220'):
        _, _, all_devices, all_bdfs, _, _  = device_manager.get_all_devices_and_bdfs()

    if len(all_devices) == 0:
        sys.exit(f"error: device device not found")

    if (IS_TEST):
        print("All Deivces:", all_devices)
        print("All BDFs:", all_bdfs)
        print()

    IS_DOCKER = args.docker

    if (args.query):
        print_query_result(all_devices, args.query, args.model)
    else:
        print_header()
        print_devices_status(all_devices, all_bdfs)
        print_processes(all_devices)

if __name__ == '__main__':
    sys.exit(__main__.main())
