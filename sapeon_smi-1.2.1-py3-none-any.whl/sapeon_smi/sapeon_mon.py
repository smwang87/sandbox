#!/usr/bin/env python3
# Copyright (c) 2022 The Sapeon Authors. All rights reserved.
# v1.0.0 - initial version, heny, 2022-10-23

import curses
from sqlite3 import Timestamp
import sys
import os
import glob
import time
import select
import platform
import random
import psutil
import signal
import argparse

IS_TEST = False
SW_VER="1.2.1"

# x220
#  0  1    2        3        4      5    6     7    8  9   10  11   12   13   14   15   16   17
# hw chip serial  prj_id  feature  s54   mcu  tmu  t1  t2  t3  t4   p1   p2            pid  tgid
# 03 00   0000   00000000 00000000 1205 1205   0   75  78   0   0   89    0    0    0   0   0

# x330
#  0  1    2        3        4        5     6     7    8    9   10   11   12    13    14   15   16  17  18  19    20   21
# rev chip rsvd1   rsvd2     serial   ande  mcu   t1   t2   t3   t4   p1   p2    p3    p4   p5   l0  l1  l2  l3   pid  tgid
# 00  00   0000   00000000  17c00007  1300  1220  74   103  65  123   600 2340 14110 15660 4048   0   0   0   0   101   0

HW_VER, CHIPIDX, RSVD1, RSVD2, SERIAL, FW_VER, MCU_VER, T1, T2, T3, T4, P1, P2, P3, P4, P5, L0, L1, L2, L3, PID, TGID,\
PID_LAST, CMD, BDF, TIMESTAMP, DEVICE = range(27)

def signal_handler(signal, frame):
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

class DeviceManager:
    def __init__(self, is_test, sort):
        self.is_test = is_test
        self.sort = sort

    def __get_bdf(self, device_type):
        if self.is_test == 0:
            command = 'lspci -n | grep 1f56:' if device_type == 'sapeon' else 'lspci -n | grep 1556:'
            stream = os.popen(command)
        else:
            file_path = f"./test/lspci_grep_1f56.txt" if device_type == 'sapeon' else f"./test/lspci_grep_1556.txt"
            stream = open(file_path)

        outputs = stream.read().splitlines()
        stream.close()
        bdfs = [out.split()[0] for out in outputs]
        return bdfs

    def __get_devices(self, device_type):
        path = f'./test/sys/class/{device_type}/' if self.is_test else f'/sys/class/{device_type}/'
        devices = sorted(glob.glob(path + f'snx3-*')) if device_type == 'sapeon' else sorted(glob.glob(path + f'{device_type}*'))
        return devices

    def get_all_devices_and_bdfs(self):
        x330_devices = self.__get_devices('sapeon')
        x330_bdfs = self.__get_bdf('sapeon')
        x220_devices = self.__get_devices('aix')
        x220_bdfs = self.__get_bdf('aix')
        all_devices = x330_devices + x220_devices
        all_bdfs = x330_bdfs + x220_bdfs

        if self.sort == True:
            sorted_data = sorted(zip(all_bdfs, all_devices), key=lambda x: int(x[0].split(':')[0], 16))
            all_bdfs = [item[0] for item in sorted_data]
            all_devices = [item[1] for item in sorted_data]

        return x330_devices, x330_bdfs, x220_devices, x220_bdfs, all_devices, all_bdfs

def get_hostinfo() :
    host = []
    host.append(f'{platform.platform()}\n')
    host.append(f'{platform.version()}\n')
    host.append(f'{platform.python_version()}\n')

    return host

def get_dmesg() :
    if IS_TEST == 0 :
        if (MODEL == 'all'):
            stream = os.popen('sudo dmesg | grep -E \'snx3|backend\' -A30')
        elif (MODEL == 'x330'):
            stream = os.popen('sudo dmesg | grep snx3 -A30')
        elif (MODEL == 'x220'):
            stream = os.popen('dmesg | grep backend: -A30')
    else :
        stream = open("./test/dmesg.txt")

    outputs = stream.read().splitlines()
    stream.close()
    dmesg = []
    for out in outputs :
        dmesg.append(f'{out}\n')

    return dmesg

def open_all_status(dev) :
    path_mon = '/aix_status_monitor'
    fds = [open(i + path_mon, 'r') for i in dev ]

    return fds

def close_all_device(fds) :
    for fd in fds :
        fd.close()

def x330_conv_card_rev(hwver) :
    conv = ''
    if str(hwver) == '00' :
        conv = 'EVB'
    elif str(hwver) == '01' :
        conv = 'I.0/1'
    elif str(hwver) == '02' :
        conv = 'I.2'
    elif str(hwver) == '03' :
        conv = 'I.3'

    return conv

def x220_conv_card_rev(hwver) :
    conv = ''
    if hwver[0] == '0' :
        conv = 'K'
    elif hwver[0] == 'A' or hwver[0] == 'a' :
        conv = 'E'
    conv = conv + hwver[1]

    return conv

def init_status(fds, bdfs) :
    global status

    status = []
    for i, fd in enumerate(fds) :
        status.append([])
        fd.seek(0)
        data = fd.readline().rstrip('\n')
        if (len(data) == 0):
            sys.exit("error: cannot read a device status")
        raw = (' '.join(data.split())).split(' ')
        if (fd.name.split('/')[-3] == 'sapeon'):
            status[i].append(x330_conv_card_rev(raw[HW_VER]))           # HW_VER
            status[i].append(int(raw[CHIPIDX]))                         # CHIPIDX
            status[i].extend(['N/A'] * 2)                               # RSVD1, RSVD2
            if(raw[SERIAL] == '00000000'):                              # SERIAL
                status[i].append('None')
            else :
                feature = raw[SERIAL]
                year = int(feature[0:2], 16)
                month = int(feature[2:3], 16) + ord("A") - 1
                model = int(feature[-5:], 16)
                model_str = '{:05d}'.format(model)
                status[i].append(str(year) + chr(month) + model_str)
            status[i].extend([raw[5], raw[6]])                          # FW_VER, MCU_VER
            status[i].extend([0] * 16)                                  # T1 ~ PID_LAST
            status[i].append('Idle')                                    # CMD
            status[i].append(bdfs[i])                                   # BDF
            status[i].append('')                                        # Timestamp
            status[i].append(fds[i].name.split('/')[-2])                # DEVICE
        elif (fd.name.split('/')[-3] == 'aix'): # convert x220 format to x330 format
            status[i].append(x220_conv_card_rev(raw[0]))                # HW_VER
            status[i].append(int(raw[1]))                               # CHIPIDX
            status[i].extend(['N/A'] * 2)                               # RSVD1, RSVD2
            status[i].append('N/A')                                     # SERIAL
            status[i].extend([raw[5], raw[6]])                          # FW_VER, MCU_VER
            status[i].extend([0] * 9)                                   # T1 ~ P5
            status[i].extend(['N/A'] * 4)                               # L0 ~ L3
            status[i].extend([0] * 3)                                   # PID, PID_LAST
            status[i].append('Idle')                                    # CMD
            status[i].append(bdfs[i])                                   # BDF
            status[i].append('')                                        # Timestamp
            status[i].append(fds[i].name.split('/')[-2])                # DEVICE

def update_status(fds) :
    global time_stamp

    raw = []
    for fd in fds :
        fd.seek(0)
        raw.append(fd.readline().rstrip())
    bufs = [ (' '.join(i.split())).split(' ') for i in raw ]

    time_stamp = time.strftime('%Y%m%d-%H%M%S', time.localtime(time.time()))

    for i, buf in enumerate(bufs) :
        if (IS_TEST) :
            rand_idx = [T1, T2, T3, T4]
            for j in rand_idx :
                buf[j] = float(buf[j]) + random.randint(-1,1)
            rand_idx = [P5]
            for j in rand_idx :
                buf[j] = int(buf[j]) + random.randint(0,100)

        status[i][TIMESTAMP] = time_stamp

        if 'snx' in status[i][DEVICE]:
            status[i][T1] = (float(buf[7]) + float(buf[8]) + float(buf[9]) + float(buf[10]))/2/4
            status[i][T2] = 'N/A'
            status[i][P5] = (float(int(buf[15]))/100) if int(buf[15]) < 0xFFFE else -1
            status[i][L0] = int( (int(buf[16]) + int(buf[17]) + int(buf[18]) + int(buf[19])) / 4)
            if IS_DOCKER:
                status[i][PID] = int(buf[21])
            else:
                status[i][PID] = int(buf[20])
        elif 'aix' in status[i][DEVICE]:
            status[i][T1] = float(buf[8])/2
            status[i][T2] = float(buf[9])/2
            status[i][P5] = round((int(buf[12])*0.025), 2) if int(buf[12]) < 0xFFFE else -1
            if IS_DOCKER:
                status[i][PID] = int(buf[17])
            else:
                status[i][PID] = int(buf[16])

        if status[i][PID] != status[i][PID_LAST] :
            status[i][PID_LAST] = status[i][PID]
            status[i][CMD] = get_shell_cmd(status[i][PID])

def get_shell_cmd(pid) :
    if pid == 0 :
        return 'Idle'
    if IS_TEST == 0 :
        with open(f'/proc/{pid}/cmdline', 'r') as f :
            cmdline = f.readline().rstrip().replace('\x00',' ')
    else :
        procs = sorted(glob.glob('/proc/*'))
        procs = procs[50:150]
        with open(f'{procs[random.randint(0,len(procs)-1)]}/cmdline', 'r') as f :
            cmdline = f.readline().rstrip().replace('\x00',' ')

    return cmdline

def print_status() :
    [print(i) for i in status]

def log_init(device_cnt) :
    # time.strftime('%c', time.localtime(time.time()))
    # >>> time.strftime('%Y-%m-%d', time.localtime(time.time()))
    global logfile_time
    time_start = time.time()
    logfile_time = time.strftime('%Y%m%d-%H%M%S', time.localtime(time_start))
    if log_en == 1 :
        logs = []
        logs.append(f'Log Start      : {logfile_time}\n')
        logs.append(f'x330 Driver (FE/BE) : {X330_FE_DRV_VER} / {X330_BE_DRV_VER}\n')
        logs.append(f'x220 Driver (FE/BE) : {X220_FE_DRV_VER} / {X220_BE_DRV_VER}\n')
        logs.append(f'\n[Bus : Devices]\n')
        [logs.append(f'{status[i][BDF]} : {status[i][DEVICE]}\n') for i in range(device_cnt)]

        #Host
        logs.append(f'\n[Host info]\n')
        logs = logs + get_hostinfo()

        logs.append(f'\n[dmesg]\n')
        logs = logs + get_dmesg()

        fp_log_host = open(f'spn_{logfile_time}_hostinfo.log', 'w')
        fp_log_host.writelines(logs)
        fp_log_host.close()

        fp_log_stat = open(f'spn_{logfile_time}_status.log', 'w')
        fp_log_stat.write(f'TIMESTAMP, DEV, TYPE, CHIPIDX, Temp1, Temp2, Power, Util, PID, Command\n')
        fp_log_stat.flush()

        return fp_log_stat

def log_update(fp) :
    time.time()
    for stat in status :
        if 'snx' in stat[DEVICE]:
            fp.write(f'{stat[TIMESTAMP]}, {stat[DEVICE]}, {stat[HW_VER]}, {stat[CHIPIDX]}, {stat[T1]:3.1f}, N/A, {stat[P5]:3.1f}, {stat[L0]}, {stat[PID]}, {stat[CMD]}\n')
        elif 'aix' in stat[DEVICE]:
            fp.write(f'{stat[TIMESTAMP]}, {stat[DEVICE]}, {stat[HW_VER]}, {stat[CHIPIDX]}, {stat[T1]:3.1f}, {stat[T2]:3.1f}, {stat[P5]:3.1f}, {stat[L0]}, {stat[PID]}, {stat[CMD]}\n')
        fp.flush()

def curses_init(stdscr, device_cnt) :
    global screen, win_mon, win_pid

    # curses.noecho()
    # # Turn off blinking cursor
    curses.curs_set(False)

    if curses.has_colors():
        curses.start_color()
        curses.init_pair(1, curses.COLOR_RED, curses.COLOR_WHITE)
        curses.init_pair(2, curses.COLOR_GREEN, curses.COLOR_BLACK)
        curses.init_pair(3, curses.COLOR_YELLOW, curses.COLOR_BLACK)
        curses.init_pair(4, curses.COLOR_BLUE, curses.COLOR_BLACK)
        curses.init_pair(5, curses.COLOR_RED, curses.COLOR_BLACK)
        curses.init_pair(6, curses.COLOR_CYAN, curses.COLOR_BLACK)

    # Get window dimensions
    y, x = stdscr.getmaxyx()
    # layout the header and footer
    stdscr.addstr(1,1, " " * (x -2),curses.color_pair(1) )
    stdscr.addstr(1,20, f"Sapeon Monitor / Logger v{SW_VER}",curses.color_pair(1) )
    stdscr.hline(2,1,"_",x)

    # test mode
    if IS_TEST == 1 :
        stdscr.addstr(9, 42, "[ TEST MODE ]",curses.color_pair(1) )

    # draw host info
    stdscr.addstr(3, 2,  f"[ Host Info ]", curses.color_pair(2))
    stdscr.addstr(3, 70, f"Start   : {logfile_time}", curses.color_pair(6))
    stdscr.addstr(4, 3,  f"- x330 Driver (FE/BE) : {X330_FE_DRV_VER} / {X330_BE_DRV_VER}", curses.color_pair(2))
    stdscr.addstr(5, 3,  f"- x220 Driver (FE/BE) : {X220_FE_DRV_VER} / {X220_BE_DRV_VER}", curses.color_pair(2))
    hostinfo = get_hostinfo()
    [stdscr.addstr(6+i, 3, f'- {host}', curses.color_pair(2)) for i, host in enumerate(hostinfo)]
    stdscr.addstr(y-2, 1, " " * (x -2),curses.color_pair(1) )
    stdscr.addstr(y-2, 5, "Hit 'q' to quit",curses.color_pair(1) )
    screen = stdscr.subwin(0, 0)
    screen.box() # Wrap screen window in box

    # monitor window
    Y_MON_WIN = 9
    H_MON_WIN = 4 + device_cnt + device_cnt - 1
    # pid window
    H_PID_WIN = device_cnt + 4
    Y_PID_WIN = Y_MON_WIN + H_MON_WIN + 2
    # calc necessary terminal size
    if y < ( Y_PID_WIN + H_PID_WIN + 2) :
        sys.exit("Error : Not enough space to draw box. Please resize the terminal")

    win_mon = stdscr.subwin(H_MON_WIN, 97, (Y_MON_WIN + 1), 1) # curses.newwin(height, width, begin_y, begin_x)
    # win_mon.hline(2, 1, curses.ACS_HLINE, 69)
    win_mon.addstr(1, 2, f"{'Dev':^8}|{'Type':^10}|{'Bus':^10}|{'SN':^12}|{'FW Ver.':^11}")
    win_mon.vline(0, 57, curses.ACS_VLINE, H_MON_WIN - 2)
    win_mon.vline(0, 58, curses.ACS_VLINE, H_MON_WIN - 2)
    win_mon.vline(1, 57, curses.ACS_VLINE, H_MON_WIN - 2)
    win_mon.vline(1, 58, curses.ACS_VLINE, H_MON_WIN - 2)
    win_mon.addstr(1, 59, f"{'Temp1':^9}|{'Temp2':^9}|{'Power':^9}|{'Util':^8}")
    win_mon.hline(2, 1, curses.ACS_HLINE, 95)
    win_mon.box()
    win_mon.addstr(0, 22, f"{'[  Card Info  ]'}")
    win_mon.addstr(0, 72, f"{'[  Status  ]'}")

    # pid window
    win_pid = stdscr.subwin(H_PID_WIN, 97, Y_PID_WIN, 1)
    win_pid.box()
    win_pid.addstr(0,27,"[ Process in use ]")
    win_pid.addstr(1,2,"  Dev   |   PID   |  Command")
    win_pid.hline(2, 1, curses.ACS_HLINE, 95)

    y = 0
    for i in range(0, device_cnt) :
        win_mon.addstr((3+y) , 2, f'{status[i][DEVICE]:^8}|{status[i][HW_VER]:^10}|{status[i][BDF]:^10}|{status[i][SERIAL]:^12}| {status[i][FW_VER]}.{status[i][MCU_VER]}')
        win_mon.hline(3+y+1, 1, curses.ACS_HLINE, 95)
        y += 1
        win_pid.addstr(3+i, 2, f'{status[i][DEVICE]:^8}|')
        y += 1

    screen.refresh()

    # Start printing text from (0,2) of the pad (first line, 3rd char)
    # on the screen at position (5,5)
    # with the maximum portion of the pad displayed being 20 chars x 15 lines
    # Since we only have one line, the 15 lines is overkill, but the 20 chars
    # will only show 20 characters before cutting off
    # pad1.refresh(0, 2, 5, 5, 15, 20)
    # pad2.refresh(0, 2, 5, 5, 15, 20)
    # pad1.refresh(0, 2, 5, 5, 15, 20)
    # pad2.refresh(0, 2, 5, 5, 15, 20)

def get_temp_color(temp) :
    if temp < 50.0 : return curses.color_pair(4)
    if temp < 70.0 : return curses.color_pair(2)
    if temp < 90.0 : return curses.color_pair(3)
    else :           return curses.color_pair(5)

def get_pwr_color(pow) :
    if pow < 10.0 : return curses.color_pair(4)
    if pow < 60.0 : return curses.color_pair(2)
    if pow < 65.0 : return curses.color_pair(3)
    else :          return curses.color_pair(5)

def draw_status(stdscr, device_cnt) :
    stdscr.addstr(4, 70, f'Current : {time_stamp}', curses.color_pair(3))
    stdscr.addstr(6, 84, f'CPU :{psutil.cpu_percent():>5}%')
    stdscr.addstr(7, 84, f'Mem :{psutil.virtual_memory().percent:>5}%')
    y = 0
    for i in range(0, device_cnt) :
        win_mon.addstr(3+y, 60, f'{float(status[i][T1]):>5.1f}\xb0C', get_temp_color(float(status[i][T1])))
        if (status[i][T2] == 'N/A'):
            win_mon.addstr(3+y, 60+10, f'{status[i][T2]:^9}')
        else:
            win_mon.addstr(3+y, 60+10, f'{float(status[i][T2]):>5.1f}\xb0C', get_temp_color(float(status[i][T2])))
        win_mon.addstr(3+y, 60+10+10, " Error" if int(status[i][P5]) <= 1 else f'{status[i][P5]:>5.1f}W',
                                    curses.color_pair(5) if int(status[i][P5]) <= 1 else get_pwr_color(status[i][P5]))
        if (status[i][L0] == 'N/A'):
            win_mon.addstr(3+y, 60+17+10, f'{status[i][L0]:>7}')
        else :
            win_mon.addstr(3+y, 60+17+10, f'{status[i][L0]:>7}%', get_temp_color(float(status[i][L0])))

        y += 1
        win_pid.addstr(3+i, 11, f'{status[i][PID]:^9d}| {status[i][CMD][:61]:<62s}')
        y += 1
    screen.refresh()

def curses_deinit() :
    # curses.nocbreak()   # Turn off cbreak mode
    # curses.echo()       # Turn echo back on
    # curses.curs_set(1)  # Turn cursor back on
    # If initialized like `my_screen = curses.initscr()`
    # my_screen.keypad(0) # Turn off keypad keys
    return 0

def main(stdscr) :
    # init
    global X330_FE_DRV_VER, X330_BE_DRV_VER, X220_FE_DRV_VER, X220_BE_DRV_VER

    device_manager = DeviceManager(is_test=IS_TEST, sort=False)

    if (MODEL == 'all'):
        x330_devices, _, x220_devices, _, all_devices, all_bdfs = device_manager.get_all_devices_and_bdfs()
    elif (MODEL == 'x330'):
        x330_devices, x330_bdfs, x220_devices, _, _, _ = device_manager.get_all_devices_and_bdfs()
        all_devices, all_bdfs = x330_devices, x330_bdfs

    elif (MODEL == 'x220'):
        x330_devices, _, x220_devices, x220_bdfs, _, _ = device_manager.get_all_devices_and_bdfs()
        all_devices, all_bdfs = x220_devices, x220_bdfs

    if (IS_TEST):
        X330_FE_DRV_VER = X330_BE_DRV_VER = X220_FE_DRV_VER = X220_BE_DRV_VER = f"vTest"
    else :
        if (len(x330_devices) != 0):
            try :
                with open("/sys/module/sapeon/version", "r") as f :
                    X330_FE_DRV_VER = f"v{f.readline().strip()}"
            except :
                sys.exit("Error : No Sapeon Device Found\n")
            with open("/sys/module/snx3/version", "r") as f :
                X330_BE_DRV_VER = f"v{f.readline().strip()}"
        else:
            X330_FE_DRV_VER = X330_BE_DRV_VER = f"-"
        if (len(x220_devices) != 0):
            try :
                with open("/sys/module/frontend/version", "r") as f :
                    X220_FE_DRV_VER = f"v{f.readline().strip()}"
            except :
                sys.exit("Error : No Sapeon Device Found\n")
            with open("/sys/module/backend/version", "r") as f :
                X220_BE_DRV_VER = f"v{f.readline().strip()}"
        else:
            X220_FE_DRV_VER = X220_BE_DRV_VER = f"-"

    fd_stats = open_all_status(all_devices)
    dev_cnt = len(fd_stats)

    init_status(fd_stats, all_bdfs)
    fd_log = log_init(dev_cnt)
    curses_init(stdscr, dev_cnt)

    # draw
    c = ''
    curses.halfdelay(10) # Block each getch() for 10 tenths of a second
    while c != ord('q') and c != ord('Q'):
        update_status(fd_stats)
        draw_status(stdscr, dev_cnt)
        if log_en == 1 :
            log_update(fd_log)
        c = screen.getch() # Get char

    # clean up
    close_all_device(fd_stats)
    if log_en == 1 :
        fd_log.close()
    curses_deinit()

def main_wrapper() : # caller is sapeon-mon
    global log_en, MODEL, IS_DOCKER

    parser = argparse.ArgumentParser(description = 'Sapeon Monitor v' + SW_VER )
    parser.add_argument('-l', type=int, default=0, help='set 1 to enable logging')
    parser.add_argument('--model', type=str, default='all', choices=['all', 'x330', 'x220'],
            help='Choosse the model to output the information.')
    parser.add_argument('--docker', action='store_true', help='Enable docker container mode.')
    args = parser.parse_args()
    log_en, MODEL, IS_DOCKER = args.l, args.model, args.docker

    curses.wrapper(main)

if (__name__ == "__main__") : # caller is command line
    # work-aroud to pass command line arguement to main from different caller.
    global log_en, MODEL, IS_DOCKER

    parser = argparse.ArgumentParser(description = 'Sapeon Monitor v' + SW_VER )
    parser.add_argument('-l', type=int, default=0, help='set 1 to enable logging')
    parser.add_argument('--model', type=str, default='all', choices=['all', 'x330', 'x220'],
            help='Choosse the model to output the information.')
    parser.add_argument('--docker', action='store_true', help='Enable docker container mode.')
    args = parser.parse_args()
    log_en, MODEL, IS_DOCKER = args.l, args.model, args.docker

    curses.wrapper(main)
